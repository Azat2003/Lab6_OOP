﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PR2
{
    internal class Flist
    {
        public static List<Figure> figures = new List<Figure>();
    }
}
